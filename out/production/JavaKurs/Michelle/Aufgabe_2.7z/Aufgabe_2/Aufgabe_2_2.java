package Michelle.Aufgabe_2;

public class Aufgabe_2_2 {
}
